
//I'm using this awesome css Gradient Pattern from Lea Verou's Gallery: http://lea.verou.me/css3patterns/#hearts

//Also Here is my previous Valentine's pen: https://codepen.io/AngelaVelasquez/details/KqCDz/